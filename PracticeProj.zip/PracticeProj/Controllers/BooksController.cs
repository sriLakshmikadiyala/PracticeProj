﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PracticeProj.BookDbContext;
using PracticeProj.Models;

namespace PracticeProj.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly BooksDbContext dbContext;
        public BooksController(BooksDbContext db)
        {
            dbContext = db;

        }
        [HttpGet]
        [Route("GetBooks")]
        public IActionResult GetBooks()
        {
            if (dbContext.books == null)
            {
                return NotFound();
            }
            var res = dbContext.books.ToList();
            return Ok(res);
        }
        [HttpGet]
        public IActionResult GetBooksById(int id)
        {
            var res1 = dbContext.books.FirstOrDefault(x => x.Id == id);
            if(res1 == null)
            {
                return NotFound();

            }
            return Ok(res1);

        }
        [HttpPost]
        public IActionResult AddBook([FromBody] Books book)
        {
            var res2 = dbContext.books.Add(book);
            dbContext.SaveChanges();
            return Ok(res2);
        }

    }
}
